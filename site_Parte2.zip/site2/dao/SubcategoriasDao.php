<?php
interface SubcategoriasDao {

    public function buscaTodos();
    public function buscaPorId($id);
}
?>
