<?php

    interface ComprasDao{

        public function insere($compra);

    }


?>