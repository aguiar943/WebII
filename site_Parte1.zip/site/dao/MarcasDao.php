<?php

interface MarcasDao {

    public function buscaTodos();
    
}

?>