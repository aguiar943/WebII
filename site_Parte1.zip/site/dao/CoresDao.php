<?php

interface CoresDao {

    public function buscaTodos();
    public function buscaPorId($id);
    
}

?>
