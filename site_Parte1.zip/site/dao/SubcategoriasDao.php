<?php
interface SubcategoriasDao {

    public function buscaTodos();
}
?>
